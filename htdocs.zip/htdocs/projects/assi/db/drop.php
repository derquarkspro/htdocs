<?php

require_once "const.php";

$db_d_conn = mysqli_connect(DB_HOST, DB_USR, DB_PSW);
if (!$db_d_conn) {
  echo mysqli_connect_error();
  die("Connection failed: " . mysqli_connect_error() . "<br>");
}
db_q($db_d_conn, "DROP DATABASE `assi`");

if (isset($_GET["c"])) {
  require "create.php";
}

#echo "<br><br><br><center><p><a href=\"/index.php\">index</a></p></center>";

header("Location: /index.php");

?>