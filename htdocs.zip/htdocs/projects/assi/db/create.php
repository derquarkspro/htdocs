<?php

require_once "const.php";

$db_c_conn = mysqli_connect(DB_HOST, DB_USR, DB_PSW);
if (!$db_c_conn) {
  die("Connection failed: " . mysqli_connect_error() . "<br>");
}

db_q($db_c_conn, "CREATE DATABASE " . DB_NAME . "");

db_q($db_c_conn, "CREATE TABLE `assi`.`assis` (
  `ID` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `Vorname` VARCHAR(127) ,
  `Nachname` VARCHAR(127) ,
  `Power` TINYINT NOT NULL ,
  `Benutzername` VARCHAR(127) NOT NULL ,
  `Passwort` VARCHAR(256) NOT NULL ,
  `Email` VARCHAR(256) ,
  `Parkolino` TINYINT NOT NULL ,
  PRIMARY KEY (`ID`)) ENGINE = InnoDB;");

db_q($db_c_conn, "CREATE TABLE `assi`.`einteilung` (
  `ID` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `Assi` INT NOT NULL ,
  `Tag` TINYINT ,
  `Bf` TINYINT ,
  PRIMARY KEY (`ID`)) ENGINE = InnoDB;");

db_q($db_c_conn, "CREATE TABLE `assi`.`anders` (
  `ID` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `Datum` DATE NOT NULL ,
  `Schicht` INT NOT NULL ,
  `Assi` INT NOT NULL ,
  `Aktion` VARCHAR(127) NOT NULL ,
  PRIMARY KEY (`ID`)) ENGINE = InnoDB;");

$asd1 = sha1("<3", FALSE);
$asd2 = sha1("YHTS9X29meeCXge", FALSE);
$asd3 = sha1("M5VGzGK1oDDEEuwS", FALSE);
$asd4 = sha1("KymV9MV8iaa44dw", FALSE);

db_q($db_c_conn, "INSERT INTO `assi`.`assis` ( `Vorname`, `Nachname`, `Power`, `Benutzername`,`Passwort`, `Email`, `Parkolino`) VALUES ('Parkoline', NULL, '2', 'parkoline', '$asd1', NULL, 1);");
db_q($db_c_conn, "INSERT INTO `assi`.`assis` ( `Vorname`, `Nachname`, `Power`, `Benutzername`,`Passwort`, `Email`, `Parkolino`) VALUES (NULL, NULL, '3', 'admin', '$asd2', NULL, 0);");
db_q($db_c_conn, "INSERT INTO `assi`.`assis` ( `Vorname`, `Nachname`, `Power`, `Benutzername`,`Passwort`, `Email`, `Parkolino`) VALUES ('Assistent', 'Beispiel', '1', 'assi', '$asd3', NULL, 0);");

mysqli_close($db_c_conn);

?>
