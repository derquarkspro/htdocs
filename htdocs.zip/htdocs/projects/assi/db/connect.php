<?php

require_once "const.php";

$db_conn = mysqli_connect(DB_HOST, DB_USR, DB_PSW, DB_NAME);
if (!$db_conn) {
  echo mysqli_connect_error();
  die("Connection failed: " . mysqli_connect_error() . "<br>");
}

?>
