<?php
define ("DB_HOST", "localhost");
define ("DB_USR", "assi");
define ("DB_PSW", "M5VGzGK1oDDEEuwS");
define ("DB_NAME", "assi");

function db_q($c, $q) {
  $r = mysqli_query($c, $q) or die(mysqli_error($c));
  return mysqli_fetch_all($r, MYSQLI_ASSOC);
}
?>