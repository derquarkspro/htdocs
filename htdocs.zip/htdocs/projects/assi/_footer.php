
<footer>
<p>Copyright © 2020 - <?php echo date("Y"); ?> Viktor Lüdecke</p>
</footer>
</body>
</html>
