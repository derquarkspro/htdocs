<?php

require_once "_header.php";
require_once "db/connect.php";

$usrname = "";
$usrpswd = "";
$errors = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

  $usrname = $_POST["usrname"];
  $usrpswd = sha1($_POST["usrpswd"]);

  $r = db_q($db_conn, "SELECT * FROM `assis` WHERE `Benutzername` = \"$usrname\"");

  if (!is_null($r[0])) {
    if(sizeof($r) == 1) {

      if ($usrpswd == $r[0]["Passwort"]) {

        foreach ($r[0] as $key => $value) {
          $_SESSION[$key] = $value;
        }

        header("Location: /index.php");

      } else {
        array_push($errors, "Die Anmeldedaten konnten in der Datenbank nicht gefunden werden.");
      }
    } else {
      array_push($errors, "Datenbankfehler. Bitte kontaktieren Sie einen Administrator.");
    }
  } else {
    array_push($errors, "Die Anmeldedaten konnten in der Datenbank nicht gefunden werden.");
  }
}

?>

<section>

  <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && sizeof($errors) > 0): ?>

    <article style="max-width:720px;background-color:#ff6666;">
    
    <ul>

      <?php foreach ($errors as $value): ?>
        <li><?php echo $value; ?></li>
      <?php endforeach; ?>
      
    </ul>

    <hr>

  <?php else: ?>

    <article style="max-width:720px;">

  <?php endif; ?>

    <form action="login.php" method="post">

      <div>
        <label for="usrname"><b>Benutzername</b></label>
        <input type="text" id="usrname" placeholder="Benutzername" name="usrname" value ="<?php echo $usrname; ?>" required>
      </div>
      
      <div>
        <label for="usrpswd"><b>Passwort</b></label>
        <input type="password" id="usrpswd" placeholder="Passwort" name="usrpswd" required>
      </div>

      <input type="submit" value="Login">

    </form>

  </article>

</section>

<?php

require_once "_footer.php";

?>