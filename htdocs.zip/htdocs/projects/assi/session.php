<?php

session_start();

$_SESSION["Power"] = (isset($_SESSION["Power"])) ? $_SESSION["Power"] : 0;

$_SESSION["usrname"] = (isset($_SESSION["Vorname"]) && isset($_SESSION["Nachname"])) ? ($_SESSION["Vorname"] . " " . $_SESSION["Nachname"]) : ((isset($_SESSION["Benutzername"])) ? $_SESSION["Benutzername"] : "");

?>