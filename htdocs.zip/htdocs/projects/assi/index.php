<?php

require_once "_header.php";

$_SESSION["Power"] = (isset($_SESSION["Power"])) ? $_SESSION["Power"] : 0;

?>

<section>
  <article>
    <h3><?php echo $_SESSION["Power"]; ?></h3>

    <?php if ($_SESSION["Power"] == 0): ?>
    
      <p>nicht angemeldet</p>

    <?php elseif ($_SESSION["Power"] == 1): ?>

      <p>Assistent</p>

    <?php elseif ($_SESSION["Power"] == 2): ?>

      <p>Btrl.</p>

    <?php elseif ($_SESSION["Power"] == 3): ?>

      <p>Admin</p>

    <?php
      else: 
      require_once "logout.php?m=EinFehler";
      endif;
    ?>

  </article>
</section>

<?php

require_once "_footer.php";

?>