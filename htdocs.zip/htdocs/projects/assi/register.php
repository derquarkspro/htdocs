<?php

require_once "_header.php";
require_once "db/connect.php";

$vorname = "";
$nachname = "";
$usrname = "";
$power = "";
$parkolino = "";
$email = "";
$usrpswd = "";
$usrpswdconf = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

  $usrname = $_POST["usrname"];
  $usrpswd = sha1($_POST["usrpswd"]);

  $vorname = $_POST["vorname"];
  $nachname = $_POST["nachname"];
  $usrname = $_POST["usrname"];
  $power = $_POST["power"];
  $parkolino = $_POST["parkolino"];
  $email = $_POST["email"];
  $usrpswd = sha1($_POST["usrpswd"]);
  $usrpswdconf = sha1($_POST["usrpswdconf"]);

  $r = db_q($db_conn, "SELECT * FROM `assis` WHERE `Benutzername` = \"$usrname\"");
/*
  if (!is_null($r)) {

    if ($usrpswd == $r[0]["Passwort"]) {

      foreach ($r[0] as $key => $value) {
        $_SESSION[$key] = $value;
      }

      header("Location: /index.php");

    }

  }
*/
}

?>

<section>

  <article style="max-width: 720px;">

    <form action="register.php" method="post">

      <div>
        <label for="vorname"><b>Vorname</b></label>
        <input type="text" id="vorname" placeholder="Vorname" name="vorname" value ="<?php echo $vorname; ?>" required>
      </div>

      <div>
        <label for="nachname"><b>Nachname</b></label>
        <input type="text" id="nachname" placeholder="Nachname" name="nachname" value ="<?php echo $nachname; ?>" required>
      </div>

      <div>
        <label for="usrname"><b>Benutzername</b></label>
        <input type="text" id="usrname" placeholder="Benutzername" name="usrname" value ="<?php echo $usrname; ?>" required>
      </div>

      <div>
        <label for="power"><b>Power</b></label>
        <br>
        <input type="radio" id="1" name="power" value="Assistent" required>
        <label for="1">Assistent</label>
        <br>
        <input type="radio" id="2" name="power" value="Betriebsleitung" required>
        <label for="2">Betriebsleitung</label>
        <?php if ($_SESSION["Power"] >= 3): ?>
          <br>
          <input type="radio" id="3" name="power" value="Administrator" required>
          <label for="3">Administrator</label>
        <?php endif; ?>
      </div>

      <div>
        <label for="parkolino"><b>Einweisung Parkolino</b></label>
        <input type="checkbox" id="parkolino" placeholder="parkolino" name="parkolino" value ="<?php echo $parkolino; ?>">
      </div>

      <div>
        <label for="email"><b>E-Mail</b></label>
        <input type="email" id="email" placeholder="E-Mail" name="email" value ="<?php echo $email; ?>">
      </div>

      <div>
        <label for="usrpswd"><b>Passwort</b></label>
        <input type="password" id="usrpswd" placeholder="Passwort" name="usrpswd" required>
      </div>

      <div>
        <label for="usrpswdconf"><b>Passwort wiederholen</b></label>
        <input type="password" id="usrpswdconf" placeholder="Passwort wiederholen" name="usrpswdconf" required>
      </div>
      
      <input type="submit" value="Login erstellen">

    </form>

  </article>

</section>

<?php

require_once "_footer.php";

?>