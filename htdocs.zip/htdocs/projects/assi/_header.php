<?php

require_once "session.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="/resources/css/style.css">
  <title>Document <?php echo (isset($_SESSION["Vorname"])) ? $_SESSION["Vorname"] : ""; ?></title>
</head>
<body>
  <header>
    <h1>Assistentenonlineeintragungsliste</h1>
    <h2>Dresdner Parkseisenbahn</h2>
  </header>
  <nav>
    <a href="/index.php">Startseite</a>
    <a href="db/drop.php?c">Drop Database</a>
    <a href="register.php">Login erstellen</a>
    <?php if (isset($_SESSION["Benutzername"])): ?>
      <a href="logout.php" style="float:right;">Logout</a>
      <a href="#" style="float:right;">Angemeldet als: &lt;<?php echo ($_SESSION["usrname"]); ?>&gt;</a>
    <?php else: ?>
      <a href="login.php" style="float:right;">Login</a>
    <?php endif; ?>
  </nav>
</body>
</html>