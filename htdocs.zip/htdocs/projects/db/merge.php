<?php
//echo "<!DOCTYPE html><html><head></head><body><br>\n";
function read($file, $output, $args) {
  while(!feof($file)) {
    write($output, replace(fgets($file), $args));
  }
  fclose($file);
}
function write($file, $str) {
  if (isset($str) && $str !== "") {
    fwrite($file, $str);
  }
}
function replace(string $str, array $args) {
  $data = array(
    array('%DATUM%', '%TITLE%', '%PREV%', '%NEXT%', '%START%'),
    array(date("d.m.Y"), $args[0], $args[1], $args[2], $args[3])
  );
  for ($i=0; $i < count($data[0]); $i++) {
    if (is_numeric(strpos($str, $data[0][$i]))) {
      if (isset($data[1][$i]) && $data[1][$i] !== "") {
        $str = str_replace($data[0][$i], $data[1][$i], $str);
      } else {
        return "";
      }
    }
  }
  return $str;
}
$res = "/resources/";
$sec = $res . "sections/";
$sections = scandir(getcwd() . $sec);
for ($i=0; $i < count($sections); $i++) {
  $section = $sections[$i];
  if (!is_dir($section)) {
    //echo "<a href=\"$section\">" . $section . "</a><br><br>";
    //echo "\n" . $section . "\n";
    $sectionFile = fopen(getcwd() . $sec . $section, "r") or die("Unable to open section file!");
    $topFile = fopen(getcwd() . $res . "top.html", "r") or die("Unable to open top file!");
    $bottomFile = fopen(getcwd() . $res . "bottom.html", "r") or die("Unable to open bottom file!");
    $outputFile = fopen(getcwd() . "/" . $section, "w") or die("Unable to open output file!");
    $args = explode(";", substr(fgets($sectionFile), 4, -5));
    read($topFile, $outputFile, $args);
    read($sectionFile, $outputFile, $args);
    read($bottomFile, $outputFile, $args);
    fclose($outputFile);
    //echo "<script>window.open('$section', '_blank');</script>\n";
  }
}
//echo "</body></html>";
?>